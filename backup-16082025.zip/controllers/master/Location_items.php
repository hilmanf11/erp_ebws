<?php
date_default_timezone_set("Asia/Bangkok");
defined('BASEPATH') or exit('No direct script access allowed');
class Location_items extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->model('crud');
        //VALIDASI FORM
        $this->form_validation->set_rules('item_rm_id', 'Product No', 'required|min_length[1]|max_length[30]');
    }
    //HALAMAN UTAMA
    public function index()
    {
        if (empty($this->session->username)) {
            redirect('error_session');
        } elseif ($this->checkuserAccess($this->id_menu()) > 0) {
            $data['button'] = $this->getbutton($this->id_menu());
            $this->load->view('template/header', $data);
            $this->load->view('master/location_items');
        } else {
            redirect('error_access');
        }
    }
    //GET DATA
    public function reads($item_rm_id = "", $item_fg_id = "")
    {
        $post = isset($_POST['q']) ? $_POST['q'] : "";

        if($item_rm_id == ""){
            $item_rm_id = null;
        }else{
            $item_rm_id = base64_decode($item_rm_id);
            $where = "item_rm_id = '$item_rm_id'";
        }

        if($item_fg_id == ""){
            $item_fg_id = null;
        }else{
            $item_fg_id = base64_decode($item_fg_id);
            $where = "item_fg_id = '$item_fg_id'";
        }

        $send = $this->crud->query("SELECT a.* FROM warehouse_locations a JOIN warehouse_location_items b ON a.id = b.warehouse_location_id WHERE $where and a.number like '%$post%'");

        echo json_encode($send);
    }

    //GET DATATABLES
    public function datatables()
    {
        if ($this->input->post()) {
            $filters = json_decode($this->input->post('filterRules'));
            $page = $this->input->post('page');
            $rows = $this->input->post('rows');
            //Pagination 1-10
            $page   = isset($page) ? intval($page) : 1;
            $rows   = isset($rows) ? intval($rows) : 10;
            $offset = ($page - 1) * $rows;
            $result = array();
            //Select Query
            $this->db->select('a.*, d.location, d.area, d.rack, d.level, d.level_sub, d.capacity, (CASE WHEN a.item_rm_id is null THEN c.id ELSE b.id END) as item_rm_id, 
                (CASE WHEN a.item_rm_id is null THEN c.number ELSE b.number END) as item_rm_number, 
                (CASE WHEN a.item_rm_id is null THEN c.name ELSE b.name END) as item_rm_name');
            $this->db->from('warehouse_location_items a');
            $this->db->join('item_rm b', 'a.item_rm_id = b.id', 'left');
            $this->db->join('item_fg c', 'a.item_fg_id = c.id', 'left');
            $this->db->join('warehouse_locations d', 'a.warehouse_location_id = d.id', 'left');
            if (@count($filters) > 0) {
                foreach ($filters as $filter) {
                    if($filter->field == "item_rm_number"){
                        $this->db->group_start();
                        $this->db->like("b.number", $filter->value);
                        $this->db->or_like("c.number", $filter->value);
                        $this->db->group_end();
                    }elseif($filter->field == "item_rm_name"){
                        $this->db->group_start();
                        $this->db->like("b.name", $filter->value);
                        $this->db->or_like("c.name", $filter->value);
                        $this->db->group_end();
                    }elseif($filter->field == "location"){
                        $this->db->like("d.location", $filter->value);
                    }elseif($filter->field == "area"){
                        $this->db->like("d.area", $filter->value);
                    }elseif($filter->field == "rack"){
                        $this->db->like("d.rack", $filter->value);
                    }elseif($filter->field == "level"){
                        $this->db->like("d.level", $filter->value);
                    }elseif($filter->field == "levl_sub"){
                        $this->db->like("d.levl_sub", $filter->value);
                    }elseif($filter->field == "capacity"){
                        $this->db->like("d.capacity", $filter->value);
                    }else{
                        $this->db->like("a.". $filter->field, $filter->value);
                    }
                }
            }
            $this->db->where('a.deleted', 0);
            //Total Data
            $totalRows = $this->db->count_all_results('', false);
            //Limit 1 - 10
            $this->db->limit($rows, $offset);
            //Get Data Array
            $records = $this->db->get()->result_array();
            //Mapping Data
            $result['total'] = $totalRows;
            $result = array_merge($result, ['rows' => $records]);
            echo json_encode($result);
        }
    }
    //CREATE DATA
    public function create()
    {
        if ($this->input->post()) {
            if ($this->form_validation->run() == TRUE) {
                $post   = $this->input->post();

                $item_rm_id = $post['item_rm_id'];
                $item_fg_id = $post['item_fg_id'];
                $warehouse_location_id = $post['warehouse_location_id'];

                $warehouse_location_items = $this->crud->read('warehouse_location_items', [], ["item_rm_id" => $item_rm_id, "item_fg_id" => $item_fg_id, "warehouse_location_id" => $warehouse_location_id]);
                if(empty($warehouse_location_items)){
                    $send   = $this->crud->create('warehouse_location_items', $post);
                    echo $send;
                }else{
                    show_error("Duplicate Data");
                }
            } else {
                show_error(validation_errors());
            }
        } else {
            show_error("Cannot Process your request");
        }
    }
    //UPDATE DATA
    public function update()
    {
        if ($this->input->post()) {
            $id   = base64_decode($this->input->get('id'));
            $post = $this->input->post();
            $send = $this->crud->update('warehouse_location_items', ["id" => $id], $post);
            echo $send;
        } else {
            show_error("Cannot Process your request");
        }
    }
    //DELETE DATA
    public function delete()
    {
        $data = $this->input->post();
        $send = $this->crud->delete('warehouse_location_items', $data);
        echo $send;
    }
    //UPLOAD DATA
    public function upload()
    {
        error_reporting(0);
        require_once 'assets/vendors/excel_reader2.php';
        $target = basename($_FILES['file_upload']['name']);
        move_uploaded_file($_FILES['file_upload']['tmp_name'], $target);
        chmod($_FILES['file_upload']['name'], 0777);
        $file = $_FILES['file_upload']['name'];
        $data = new Spreadsheet_Excel_Reader($file, false);
        $total_row = $data->rowcount($sheet_index = 0);
        for ($i = 3; $i <= $total_row; $i++) {
            $datas[] = array(
                'item_number' => $data->val($i, 2),
                'location_number' => $data->val($i, 3)
            );
        }
        $datas['total'] = count($datas);
        echo json_encode($datas);
        unlink($_FILES['file_upload']['name']);
    }
    public function uploadclearFailed()
    {
        @unlink('excel/failed/warehouse_location_items.txt');
    }
    public function uploadcreateFailed()
    {
        if ($this->input->post()) {
            $message = $this->input->post('message');
            $textFailed = fopen('excel/failed/warehouse_location_items.txt', 'a');
            fwrite($textFailed, $message . "\n");
            fclose($textFailed);
        }
    }
    public function uploadDownloadFailed()
    {
        $file = "excel/failed/warehouse_location_items.txt";
        header('Content-Description: File Failed');
        header('Content-Disposition: attachment; filename=' . basename($file));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . @filesize($file));
        header("Content-Type: text/plain");
        @readfile($file);
    }
    public function uploadcreate()
    {
        if ($this->input->post()) {
            $data = $this->input->post('data');
            $item_rm = $this->crud->read('item_rm', [], ["number" => $data['item_number']]);
            $item_fg = $this->crud->read('item_fg', [], ["number" => $data['item_number']]);

            if($item_rm){
                $item_rm_id = @$item_rm->id;
                $type = "RM";
            }else{
                $item_rm_id = null;
                $type = "FG";
            }

            if($item_fg){
                $item_fg_id = @$item_fg->id;
                $type = "FG";
            }else{
                $item_fg_id = null;
                $type = "RM";
            }

            $warehouse_locations = $this->crud->read('warehouse_locations', [], ["number" => $data['location_number'], "type" => $type]);
            $warehouse_location_items = $this->crud->read('warehouse_location_items', [], ["item_rm_id" => $item_rm_id, "item_fg_id" => $item_fg_id, "warehouse_location_id" => @$warehouse_locations->id]);
        
            if (empty($warehouse_locations)) {
                echo json_encode(array("title" => "Not Found", "message" => "Location Number " . $data['location_number'] . " Not Found", "theme" => "error"));
            } elseif (empty($item_rm) && empty($item_fg)) {
                echo json_encode(array("title" => "Not Found", "message" => "Part No " . $data['item_number'] . " Not Found", "theme" => "error"));
            } elseif (!empty($warehouse_location_items)) {
                echo json_encode(array("title" => "Duplicate", "message" => "Code " . $data['number'] . " Duplicate", "theme" => "error"));
            } else {
                $send   = $this->crud->create('warehouse_location_items', [
                    "type" => $type,
                    "item_rm_id" => $item_rm_id,
                    "item_fg_id" => $item_fg_id,
                    "warehouse_location_id" => @$warehouse_locations->id,
                ]);
                echo $send;
            }
        }
    }
    //PRINT & EXCEL DATA
    public function print($option = "")
    {
        if ($option == "excel") {
            $format  = date("Ymd");
            header("Content-type: application/vnd-ms-excel");
            header("Content-Disposition: attachment; filename=warehouse_location_items_$format.xls");
        }
        //Config
        $this->db->select('*');
        $this->db->from('config');
        $config = $this->db->get()->row();

        $this->db->select('a.*, (CASE WHEN a.item_rm_id is null THEN c.number ELSE b.number END) as item_number, (CASE WHEN a.item_rm_id is null THEN c.name ELSE b.name END) as item_name');
        $this->db->from('warehouse_location_items a');
        $this->db->join('item_rm b', 'a.item_rm_id = b.id', 'left');
        $this->db->join('item_fg c', 'a.item_fg_id = c.id', 'left');
        $this->db->where('a.deleted', 0);
        $records = $this->db->get()->result_array();

        $html = '<html><head><title>Print Data</title></head><style>body {font-family: Arial, Helvetica, sans-serif;}#customers {border-collapse: collapse;width: 100%;font-size: 12px;}#customers td, #customers th {border: 1px solid #ddd;padding: 2px;}#customers tr:nth-child(even){background-color: #f2f2f2;}#customers tr:hover {background-color: #ddd;}#customers th {padding-top: 2px;padding-bottom: 2px;text-align: left;color: black;}</style><body>
        <center>
            <div style="float: left; font-size: 12px; text-align: left;">
                <table style="width: 100%;">
                    <tr>
                        <td width="50" style="font-size: 12px; vertical-align: top; text-align: center; vertical-align:jus margin-right:10px;">
                            <img src="' . $config->favicon . '" width="30">
                        </td>
                        <td style="font-size: 14px; text-align: left; margin:2px;">
                            <b>' . $config->name . '</b><br>
                            <small>WAREHOUSE RM LOCATION ITEM</small>
                        </td>
                    </tr>
                </table>
            </div>
            <div style="float: right; font-size: 12px; text-align: right;">
                Print Date ' . date("d M Y H:i:s") . ' <br>
                Print By ' . $this->session->username . '  
            </div>
        </center>
        <br><br><br>
        
        <table id="customers" border="1">
            <tr>
                <th width="20">No</th>
                <th>Type</th>
                <th>Product No</th>
                <th>Product Name</th>
                <th>Location</th>
                <th>Area</th>
                <th>Rack</th>
                <th>Level</th>
                <th>Level Sub</th>
            </tr>';
        $no = 1;
        foreach ($records as $data) {
            $html .= '<tr>
                    <td>' . $no . '</td>
                    <td>' . $data['type'] . '</td>
                    <td>' . $data['item_number'] . '</td>
                    <td>' . $data['item_name'] . '</td>
                    <td>' . $data['location'] . '</td>
                    <td>' . $data['area'] . '</td>
                    <td>' . $data['rack'] . '</td>
                    <td>' . $data['level'] . '</td>
                    <td>' . $data['level_sub'] . '</td>';
            $no++;
        }
        $html .= '</table></body></html>';
        echo $html;
    }
}
