<?php
error_reporting(0);
defined('BASEPATH') or exit('No direct script access allowed');

class Umh_all extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->model('crud');
        // $this->load->model('banshu');

        //Validasi Form
        $this->form_validation->set_rules('product_no', 'Product No', 'required|min_length[2]|max_length[30]');
    }

    public function index()
    {
        if (empty($this->session->username)) {
            redirect('error_session');
        } elseif ($this->checkuserAccess($this->id_menu()) > 0) {
            $data['button'] = $this->getbutton($this->id_menu());

            // //Process Main Number
            // $this->db->select('COUNT(a.number) as total, a.number, a.name');
            // $this->db->from('mst_process_main a');
            // $this->db->join('mst_process_sub b', 'a.number = b.process_main_number');
            // $this->db->join('mst_process c', 'b.number = c.process_sub_number');
            // $this->db->where('a.deleted_is', 0);
            // $this->db->group_by('a.number');
            // $this->db->order_by('b.flag', 'asc');
            // $processMainNumber = $this->db->get()->result_array();

            // //Process Sub Number
            // $this->db->select('COUNT(b.number) as total, b.number, b.name, a.name as main');
            // $this->db->from('mst_process_main a');
            // $this->db->join('mst_process_sub b', 'a.number = b.process_main_number');
            // $this->db->join('mst_process c', 'b.number = c.process_sub_number');
            // $this->db->where('a.deleted_is', 0);
            // $this->db->group_by('b.number');
            // $this->db->order_by('b.flag', 'asc');
            // $processSubNumber = $this->db->get()->result_array();

            // //Process Main Number
            // $this->db->select('c.number, c.name, a.name as main');
            // $this->db->from('mst_process_main a');
            // $this->db->join('mst_process_sub b', 'a.number = b.process_main_number');
            // $this->db->join('mst_process c', 'b.number = c.process_sub_number');
            // $this->db->where('a.deleted_is', 0);
            // $this->db->group_by('c.number');
            // $this->db->order_by('b.flag', 'asc');
            // $processNumber = $this->db->get()->result_array();

            // $no = 1;
            // foreach ($processNumber as $process) {
            //     $arrProcess[] = array(
            //         "main" => $process['main'],
            //         "number" => $process['number'],
            //         "name" => $process['name']
            //     );
            //     $no++;
            // }

            $data['mainProcess'] = @$processMainNumber;
            $data['subProcess'] = @$processSubNumber;
            $data['process'] = !empty($arrProcess) ? $arrProcess : [];

            $this->load->view('template/header', $data);
            $this->load->view('planning/umh_all');
        } else {
            redirect('error_access');
        }
    }

    public function datatables()
    {
        if ($this->input->get()) {
            $page = $this->input->post('page');
            $rows = $this->input->post('rows');
            //Pagination 1-10
            $page   = isset($page) ? intval($page) : 1;
            $rows   = isset($rows) ? intval($rows) : 10;
            $offset = ($page - 1) * $rows;
            $result = array();

            $id = isset($_POST['id']) ? $_POST['id'] : 0;
            $ex = explode("_", $id);
            $filter_line_no = base64_decode($this->input->get('filter_line_no'));
            $filter_product_no = trim(base64_decode($this->input->get('filter_product_no')));

            if ($id == 0) {
                //Select Query
                $this->db->select('*, SUM(cycle_time) as total_umh');
                $this->db->from('umh');
                $this->db->where('deleted_is', 0);
                $this->db->like('line_no', $filter_line_no);
                $this->db->like('product_no', $filter_product_no);
                $this->db->group_by('line_no');
                $this->db->order_by('line_no', 'asc');
                $records = $this->db->get()->result_array();

                foreach ($records as $record) {
                    $line_no = $record['line_no'];
                    $line_name = $record['line_name'];
                    $product_no = $record['product_no'];

                    $this->db->select('*, SUM(cycle_time) as total_umh_havcp');
                    $this->db->from('umh_havcp');
                    $this->db->where('deleted_is', 0);
                    $this->db->like('line_no', $filter_line_no);
                    $this->db->like('product_no', $filter_product_no);
                    $this->db->group_by('line_no');
                    $this->db->order_by('line_no', 'asc');
                    $havcp = $this->db->get()->row();

                    $arr = array(
                        "id" => "1" . "_" . $line_no,
                        "state" => "closed",
                        "line_no" => $line_no,
                        "line_name" => $line_name,
                        "circuit_no" => "-",
                        "total" => round($record['total_umh'] + @$havcp->total_umh_havcp, 3),
                        "total_umh" => round(($record['total_umh'] + @$havcp->total_umh_havcp) / 3600, 3),
                    );

                    //Process Number
                    $this->db->select('c.number, (SUM(coalesce(d.cycle_time,0))) as cycle_time');
                    $this->db->from('mst_process_main a');
                    $this->db->join('mst_process_sub b', 'a.number = b.process_main_number');
                    $this->db->join('mst_process c', 'b.number = c.process_sub_number');
                    $this->db->join('umh d', 'c.number = d.process_number');
                    $this->db->where('d.deleted_is', 0);
                    $this->db->where('d.line_no', $line_no);
                    $this->db->like('d.product_no', $filter_product_no);
                    $this->db->group_by('c.number');
                    $this->db->order_by('b.flag', 'asc');
                    $processNumber = $this->db->get()->result_array();

                    $this->db->select('c.number, (SUM(coalesce(d.cycle_time,0))) as cycle_time');
                    $this->db->from('mst_process_main a');
                    $this->db->join('mst_process_sub b', 'a.number = b.process_main_number');
                    $this->db->join('mst_process c', 'b.number = c.process_sub_number');
                    $this->db->join('umh_havcp d', 'c.number = d.process_number');
                    $this->db->where('d.deleted_is', 0);
                    $this->db->where('d.line_no', $line_no);
                    $this->db->like('d.product_no', $filter_product_no);
                    $this->db->group_by('c.number');
                    $this->db->order_by('b.flag', 'asc');
                    $processNumber2 = $this->db->get()->result_array();

                    $arrProcess = array();
                    foreach ($processNumber as $process) {
                        $arrProcess += array(
                            $process['number'] => $process['cycle_time']
                        );
                    }

                    $arrProcess2 = array();
                    foreach ($processNumber2 as $process2) {
                        $arrProcess2 += array(
                            $process2['number'] => $process2['cycle_time']
                        );
                    }
                    $arrFinal[] = array_merge(array_merge($arr, $arrProcess), $arrProcess2);
                }
            } else {
                $explode = explode("_", $id);
                //Select Query
                $this->db->select('*, SUM(cycle_time) as total_umh');
                $this->db->from('umh');
                $this->db->where('deleted_is', 0);
                $this->db->where('line_no', $explode[1]);
                $this->db->like('product_no', $filter_product_no);
                $this->db->group_by('product_no');
                $this->db->order_by('product_no', 'asc');
                $records = $this->db->get()->result_array();

                foreach ($records as $record) {
                    $line_no = $record['line_no'];
                    $product_no = $record['product_no'];

                    $this->db->select('*, SUM(cycle_time) as total_umh_havcp');
                    $this->db->from('umh_havcp');
                    $this->db->where('deleted_is', 0);
                    $this->db->where('line_no', $line_no);
                    $this->db->where('product_no', $product_no);
                    $this->db->group_by('product_no');
                    $this->db->order_by('product_no', 'asc');
                    $havcp = $this->db->get()->row();

                    $arr = array(
                        "line_no" => $product_no,
                        "line_name" => $product_no,
                        "product_no" => $product_no,
                        "total" => round($record['total_umh'] + @$havcp->total_umh_havcp, 3),
                        "total_umh" => round(($record['total_umh'] + @$havcp->total_umh_havcp) / 3600, 3),
                    );

                    //Process Number
                    $this->db->select('c.number, (SUM(coalesce(d.cycle_time,0))) as cycle_time');
                    $this->db->from('mst_process_main a');
                    $this->db->join('mst_process_sub b', 'a.number = b.process_main_number');
                    $this->db->join('mst_process c', 'b.number = c.process_sub_number');
                    $this->db->join('umh d', 'c.number = d.process_number');
                    $this->db->where('d.deleted_is', 0);
                    $this->db->where('d.line_no', $line_no);
                    $this->db->where('d.product_no', $product_no);
                    $this->db->group_by('c.number');
                    $this->db->order_by('b.flag', 'asc');
                    $processNumber = $this->db->get()->result_array();

                    $this->db->select('c.number, (SUM(coalesce(d.cycle_time,0))) as cycle_time');
                    $this->db->from('mst_process_main a');
                    $this->db->join('mst_process_sub b', 'a.number = b.process_main_number');
                    $this->db->join('mst_process c', 'b.number = c.process_sub_number');
                    $this->db->join('umh_havcp d', 'c.number = d.process_number');
                    $this->db->where('d.deleted_is', 0);
                    $this->db->where('d.line_no', $line_no);
                    $this->db->where('d.product_no', $product_no);
                    $this->db->group_by('c.number');
                    $this->db->order_by('b.flag', 'asc');
                    $processNumber2 = $this->db->get()->result_array();

                    $arrProcess = array();
                    foreach ($processNumber as $process) {
                        $arrProcess += array(
                            $process['number'] => $process['cycle_time']
                        );
                    }

                    $arrProcess2 = array();
                    foreach ($processNumber2 as $process2) {
                        $arrProcess2 += array(
                            $process2['number'] => $process2['cycle_time']
                        );
                    }
                    $arrFinal[] = array_merge(array_merge($arr, $arrProcess), $arrProcess2);
                }
            }

            //Mapping Data
            // $result['total'] = $totalRows;
            $result = !empty($arrFinal) ? $arrFinal : [];
            echo json_encode($result);
        }
    }

    public function print($option = "")
    {
        if ($option == "excel") {
            $format  = date("Ymd");
            header("Content-type: application/vnd-ms-excel");
            header("Content-Disposition: attachment; filename=umh_havcp_$format.xls");
        }

        $filter_line_no = base64_decode($this->input->get('filter_line_no'));
        $filter_product_no = base64_decode($this->input->get('filter_product_no'));

        //Config
        $this->db->select('*');
        $this->db->from('config');
        $config = $this->db->get()->row();

        //Process Main Number
        $this->db->select('COUNT(a.number) as total, a.number, a.name');
        $this->db->from('mst_process_main a');
        $this->db->join('mst_process_sub b', 'a.number = b.process_main_number');
        $this->db->join('mst_process c', 'b.number = c.process_sub_number');
        $this->db->where('a.deleted_is', 0);
        $this->db->group_by('a.number');
        $this->db->order_by('b.flag', 'asc');
        $processMainNumber = $this->db->get()->result_array();

        //Process Sub Number
        $this->db->select('COUNT(b.number) as total, b.number, b.name');
        $this->db->from('mst_process_main a');
        $this->db->join('mst_process_sub b', 'a.number = b.process_main_number');
        $this->db->join('mst_process c', 'b.number = c.process_sub_number');
        $this->db->where('a.deleted_is', 0);
        $this->db->group_by('b.number');
        $this->db->order_by('b.flag', 'asc');
        $processSubNumber = $this->db->get()->result_array();

        //Process Main Number
        $this->db->select('c.number, c.name');
        $this->db->from('mst_process_main a');
        $this->db->join('mst_process_sub b', 'a.number = b.process_main_number');
        $this->db->join('mst_process c', 'b.number = c.process_sub_number');
        $this->db->where('a.deleted_is', 0);
        $this->db->group_by('c.number');
        $this->db->order_by('b.flag', 'asc');
        $processNumber = $this->db->get()->result_array();

        //Select Query
        $this->db->select('*, SUM(cycle_time) as total_umh');
        $this->db->from('umh');
        $this->db->where('deleted_is', 0);
        $this->db->where('line_no', $filter_line_no);
        $this->db->like('product_no', $filter_product_no);
        $this->db->group_by('product_no');
        $this->db->order_by('product_no', 'asc');
        $records = $this->db->get()->result_array();

        $html = '<html><head><title>Print Data</title></head><style>body {font-family: Arial, Helvetica, sans-serif;}#customers {border-collapse: collapse;width: 100%;font-size: 12px;}#customers td, #customers th {border: 1px solid #ddd;padding: 2px;}#customers tr:nth-child(even){background-color: #f2f2f2;}#customers tr:hover {background-color: #ddd;}#customers th {padding-top: 2px;padding-bottom: 2px;text-align: left;color: black;}</style><body>
        <center>
            <div style="float: left; font-size: 12px; text-align: left;">
                <table style="width: 100%;">
                    <tr>
                        <td width="50" style="font-size: 12px; vertical-align: top; text-align: center; vertical-align:jus margin-right:10px;">
                            <img src="' . base_url('assets/image/config/' . $config->logo) . '" width="30">
                        </td>
                        <td style="font-size: 14px; text-align: left; margin:2px;">
                            <b>' . $config->name . '</b><br>
                            <small>MASTER UNIT MAN HOUR (ALL)</small>
                        </td>
                    </tr>
                </table>
            </div>
            <div style="float: right; font-size: 12px; text-align: right;">
                Print Date ' . date("d M Y H:m:s") . ' <br>
                Print By ' . $this->session->username . '  
            </div>
        </center>
        <br><br><br>
        
        <table id="customers" border="1">
            <tr>
                <th rowspan="3" style="text-align:center;"width="20">No</th>
                <th rowspan="3" style="text-align:center;">Product No</th>';
        foreach ($processMainNumber as $main) {
            $html .= '<th style="text-align:center;" colspan="' . $main['total'] . '"> ' . $main['name'] . '</th>';
        }

        $html .= '<th style="text-align:center;" rowspan="3">Total HAVCP</th>
                </tr><tr>';

        foreach ($processSubNumber as $sub) {
            $html .= '<th style="text-align:center;" colspan="' . $sub['total'] . '"> ' . $sub['name'] . '</th>';
        }

        $html .= '</tr><tr>';

        foreach ($processNumber as $proces) {
            $html .= '<th style="text-align:center;"> ' . $proces['name'] . '</th>';
        }

        $html .= '</tr>';

        $no = 1;
        $arrFinal = array();
        foreach ($records as $record) {
            $line_no = $record['line_no'];
            $customer_id = $record['customer_id'];
            $customer_name = $record['customer_name'];
            $product_no = $record['product_no'];

            $this->db->select('*, SUM(cycle_time) as total_umh_havcp');
            $this->db->from('umh_havcp');
            $this->db->where('deleted_is', 0);
            $this->db->where('line_no', $line_no);
            $this->db->where('product_no', $product_no);
            $this->db->group_by('product_no');
            $this->db->order_by('product_no', 'asc');
            $havcp = $this->db->get()->row();

            $arr = array(
                "line_no" => $line_no,
                "customer_id" => $customer_id,
                "customer_name" => $customer_name,
                "product_no" => $product_no,
                "remarks" => $record['remarks'],
                "total_umh" => round($record['total_umh'] + $havcp->total_umh_havcp, 3),
            );

            //Process Number
            $this->db->select('c.number, (SUM(coalesce(d.cycle_time,0))) as cycle_time');
            $this->db->from('mst_process_main a');
            $this->db->join('mst_process_sub b', 'a.number = b.process_main_number');
            $this->db->join('mst_process c', 'b.number = c.process_sub_number');
            $this->db->join('umh d', 'c.number = d.process_number');
            $this->db->where('d.deleted_is', 0);
            $this->db->where('d.line_no', $line_no);
            $this->db->where('d.product_no', $product_no);
            $this->db->group_by('c.number');
            $this->db->order_by('b.flag', 'asc');
            $processNumber = $this->db->get()->result_array();

            $this->db->select('c.number, (SUM(coalesce(d.cycle_time,0))) as cycle_time');
            $this->db->from('mst_process_main a');
            $this->db->join('mst_process_sub b', 'a.number = b.process_main_number');
            $this->db->join('mst_process c', 'b.number = c.process_sub_number');
            $this->db->join('umh_havcp d', 'c.number = d.process_number');
            $this->db->where('d.deleted_is', 0);
            $this->db->where('d.line_no', $line_no);
            $this->db->where('d.product_no', $product_no);
            $this->db->group_by('c.number');
            $this->db->order_by('b.flag', 'asc');
            $processNumber2 = $this->db->get()->result_array();

            $arrProcess = array();
            foreach ($processNumber as $process) {
                $arrProcess += array(
                    $process['number'] => $process['cycle_time']
                );
            }

            $arrProcess2 = array();
            foreach ($processNumber2 as $process2) {
                $arrProcess2 += array(
                    $process2['number'] => $process2['cycle_time']
                );
            }
            $arrFinal[] = array_merge(array_merge($arr, $arrProcess), $arrProcess2);
        }

        foreach ($arrFinal as $final) {
            $html .= '  <tr>
                        <td style="text-align:center;">' . $no . '</td>
                        <td style="mso-number-format:\@;">' . $final['product_no'] . '</td>';
            foreach ($processNumber as $proses) {
                $number = $proses['number'];
                $html .= '<td style="text-align:center;"> ' . @$final["$number"] . '</td>';
            }
            $html .= '  <td style="text-align:center;">' . $final['total_umh'] . '</td>
                        </tr>';
            $no++;
        }

        $html .= '</table></body></html>';
        echo $html;
    }
}
