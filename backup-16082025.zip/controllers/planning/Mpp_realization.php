<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Mpp_realization extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->model('crud');
        //$this->load->model('banshu');
        //$this->pg = $this->load->database('pg', TRUE);

        //Validasi Form
        $this->form_validation->set_rules('product_no', 'Product No', 'required|min_length[2]|max_length[50]|is_unique[mpp_realization.product_no]');
    }

    public function index()
    {
        if (empty($this->session->username)) {
            redirect('error_session');
        } elseif ($this->checkuserAccess($this->id_menu()) > 0) {
            $data['button'] = $this->getbutton($this->id_menu());
            $this->load->view('template/header', $data);
            $this->load->view('planning/mpp_realization');
        } else {
            redirect('error_access');
        }
    }

    public function print($option = "")
    {
        error_reporting(0);
        if ($option == "excel") {
            $format  = date("Ymd");
            header("Content-type: application/vnd-ms-excel");
            header("Content-Disposition: attachment; filename=mpp_realization_$format.xls");
        }

        //Config
        $this->db->select('*');
        $this->db->from('config');
        $config = $this->db->get()->row();

        //Database Server MRP
        // $this->dummy = $this->load->database('dummy', TRUE);

        //Filter Data
        $filter_month = base64_decode($this->input->get('filter_month'));
        $filter_year = base64_decode($this->input->get('filter_year'));
        $filter_customer = base64_decode($this->input->get('filter_customer'));
        $filter_product_no = base64_decode($this->input->get('filter_product_no'));
        $filter_revision = base64_decode($this->input->get('filter_revision'));

        $firstDate = date('01 M', strtotime($filter_year . "-" . $filter_month . "-01"));
        $endDate = date('t M', strtotime($filter_year . "-" . $filter_month . "-01"));

        $this->db->select("a.*, c.number as item_fg_number, c.name as item_fg_name, c.number_customer, b.name as customer_name");
        $this->db->from('generate_mpp a');
        $this->db->join('customers b', 'a.customer_id = b.id');
        $this->db->join('item_fg c', 'a.item_fg_id = c.id');
        $this->db->where('a.p_month', $filter_month);
        $this->db->where('a.p_year', $filter_year);
        $this->db->where('a.revision', $filter_revision);
        $this->db->like('a.customer_id', $filter_customer);
        $this->db->like('a.item_fg_id', $filter_product_no);
        $this->db->group_by('a.item_fg_id');
        $records = $this->db->get()->result_array();

        //Setting Header
        $styles = "";
        $wp = '<tr>';
        $wp_content = "";
        $cut = '<tr>';
        $cut_no = 0;
        $cut_content = "";
        $date = '<tr>';
        $content = '';
        $no = 1;

        while (strtotime($firstDate) <= strtotime($endDate)) {
            if (date('w', strtotime($firstDate)) !== '0') {
                $styles = "";
                $wp_content = "W/P";
                $cut_no += 1;
                $cut_content = $cut_no;
            } else {
                $styles = 'background:#FFC2C2;';
                $wp_content = "";
                $cut_no += 0;
                $cut_content = "";
            }

            //Setting Header
            $wp .= '<th width="50" style="text-align:center; ' . $styles . '">' . $wp_content . '</th>';
            $cut .= '<th width="50" style="text-align:center; ' . $styles . '">' . $cut_content . '</th>';
            $date .= '<th width="50" style="text-align:center; ' . $styles . '">' . $firstDate . '</th>';

            $firstDate = date("d M", strtotime("+1 day", strtotime($firstDate)));
        }

        //Setting Header
        $wp .= '</tr>';
        $cut .= '</tr>';
        $date .= '</tr>';

        foreach ($records as $record) {
            $day = 1;
            $i = 0;
            $firstDate2 = date('01 M', strtotime($filter_year . "-" . $filter_month . "-01"));
            $endDate2 = date('t M', strtotime($filter_year . "-" . $filter_month . "-01"));
            $period = $filter_year . $filter_month;

            // $this->dummy->select('item_id, wp, SUM(qty) as qty');
            // $this->dummy->from("serial_barcode_packing");
            // $this->dummy->where("mpp_periode", $period);
            // $this->dummy->where("item_id", $record['product_no']);
            // $this->dummy->where("sts_in", true);
            // $this->dummy->group_by("wp, item_id");
            // $this->dummy->order_by("wp", "asc");
            // $packings = $this->dummy->get()->result_array();

            $content .= "<tr>
                         <td rowspan='3'>" . $no . "</td>
                         <td rowspan='3'>" . $record['item_fg_number'] . "</td>
                         <td rowspan='3'>" . $record['number_customer'] . "</td>
                         <td rowspan='3'>" . $record['item_fg_name'] . "</td>
                         <td rowspan='3'>" . $record['circuit_no'] . "</td>
                         <td rowspan='3'>" . $record['prod_plan'] . "</td>
                         <td>PLAN QTY</td>";

            $content_packing = "";
            $content_ost = "";
            while (strtotime($firstDate2) <= strtotime($endDate2)) {
                $field_day = "date_".$day;

                if(@$packings[$i]['qty'] == ""){
                    $qty_packing = 0;
                }else{
                    $qty_packing = @$packings[$i]['qty'];
                }

                if (is_numeric(@$record[$field_day])) {
                	$date_qty = @$record[$field_day];
                }else{
                	$date_qty = 0;
                }

                //Setting Content
                if (@$record[$field_day] == "W") {
                    $content .= "<td style='background:#FFC2C2;'>0</td>";
                    $content_packing .= "<td style='background:#FFC2C2;'>0</td>";
                    $content_ost .= "<td style='background:#FFC2C2;'>0</td>";
                } else {
                    $content .= "<td>" . $record[$field_day] . "</td>";
                    $content_packing .= "<td>" . @$qty_packing . "</td>";
                    $content_ost .= "<td>" . (@$date_qty - $qty_packing) . "</td>";
                    $i++;
                }

                $firstDate2 = date("d M", strtotime("+1 day", strtotime($firstDate2)));
                $day++;
            }

            $content .= '</tr>';
            $content .= "<tr><td>ACT QTY</td>" . $content_packing . "</tr>";
            $content .= "<tr><td>OST QTY</td>" . $content_ost . "</tr>";
            $no++;
        }

        $html = '<html><head><title>Print Data</title></head><style>body {font-family: Arial, Helvetica, sans-serif;}#customers {border-collapse: collapse;font-size: 10px;}#customers td, #customers th {border: 1px solid #ddd;padding: 2px;}#customers tr:nth-child(even){background-color: #f2f2f2;}#customers tr:hover {background-color: #ddd;}#customers th {padding-top: 2px;padding-bottom: 2px;text-align: left;color: black;} .str{ mso-number-format:\@; } </style><body>
        <center>
            <div style="float: left; font-size: 12px; text-align: left;">
                <table style="width: 100%;">
                    <tr>
                        <td width="50" style="font-size: 12px; vertical-align: top; text-align: center; vertical-align:jus margin-right:10px;">
                            <img src="' . $config->logo . '" width="30">
                        </td>
                        <td style="font-size: 14px; text-align: left; margin:2px;">
                            <b>' . $config->name . '</b><br>
                            <small>' . $config->description . '</small>
                        </td>
                    </tr>
                </table>
            </div>
            <div style="float: right; font-size: 12px; text-align: right;">
                Print Date ' . date("d M Y H:m:s") . ' <br>
                Print By ' . $this->session->username . '  
            </div>
        </center>
        <br><br>
        <center><h2 style="margin:0;">MPP REALIZATION</h2><p style="margin:0;">Period '.$filter_year.'/'.$filter_month.' Revision '.$filter_revision.'</p></center>
        <br>

        <table id="customers" border="1" style="width:120%;">
            <tr>
                <th style="text-align:center;" rowspan="4" width="20">NO</th>
                <th style="text-align:center;" width="200" rowspan="4">PRODUCT EBWS</th>
                <th style="text-align:center;" width="200" rowspan="4">PRODUCT CUSTOMER</th>
                <th style="text-align:center;" width="150" rowspan="4">DESCRIPTION</th>
                <th style="text-align:center;" width="50" rowspan="4">CCT</th>
                <th style="text-align:center;" width="50" rowspan="4">PRODPLAN</th>
                <th style="text-align:center;" width="50" rowspan="4">DESC</th>
            </tr>' . $wp . $cut . $date . $content;
        echo $html;
    }
}
