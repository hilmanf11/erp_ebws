<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Journal_types extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->model('crud');

        //VALIDASI FORM
        $this->form_validation->set_rules('number', 'Code', 'required|min_length[1]|max_length[20]|is_unique[currencies.number]');
    }

    //HALAMAN UTAMA
    public function index()
    {
        if (empty($this->session->username)) {
            redirect('error_session');
        } elseif ($this->checkuserAccess($this->id_menu()) > 0) {
            $data['button'] = $this->getbutton($this->id_menu());
            $this->load->view('template/header', $data);
            $this->load->view('finance/journal_types');
        } else {
            redirect('error_access');
        }
    }

    //GET DATA
    public function reads($module = "", $module_type = "")
    {
        $post = isset($_POST['q']) ? $_POST['q'] : "";
        $module = base64_decode($module);

        if($module_type != ""){
            $module_type = base64_decode($module_type);

            if($module == "AR RECEIPT"){
                $send = $this->crud->query("SELECT a.id, a.name, c.account_number, c.account_name 
                    FROM journal_types a 
                    LEFT JOIN journal_setups b ON a.id = b.journal_type_id and b.ar_receipt = 'YES'
                    LEFT JOIN account_coa c ON b.account_number = c.account_number 
                    WHERE a.name like '%$post%' and a.module like '%$module%' and a.module_type like '%$module_type%' ORDER BY a.name ASC");
            }elseif($module == "AP PAYMENT"){
                $send = $this->crud->query("SELECT a.id, a.name, c.account_number, c.account_name 
                    FROM journal_types a 
                    LEFT JOIN journal_setups b ON a.id = b.journal_type_id and b.ap_payment = 'YES'
                    LEFT JOIN account_coa c ON b.account_number = c.account_number 
                    WHERE a.name like '%$post%' and a.module like '%$module%' and a.module_type like '%$module_type%' ORDER BY a.name ASC");
            }else{
                $send = $this->crud->reads('journal_types', ["name" => $post, "module" => $module, "module_type" => $module_type], [], "", "name", "asc");
            }

            echo json_encode($send);
        }else{
            if($module == "AR RECEIPT"){
                $send = $this->crud->query("SELECT a.id, a.name, c.account_number, c.account_name 
                    FROM journal_types a 
                    LEFT JOIN journal_setups b ON a.id = b.journal_type_id and b.ar_receipt = 'YES'
                    LEFT JOIN account_coa c ON b.account_number = c.account_number 
                    WHERE a.name like '%$post%' and a.module like '%$module%' ORDER BY a.name ASC");
            }elseif($module == "AP PAYMENT"){
                $send = $this->crud->query("SELECT a.id, a.name, c.account_number, c.account_name 
                    FROM journal_types a 
                    LEFT JOIN journal_setups b ON a.id = b.journal_type_id and b.ap_payment = 'YES'
                    LEFT JOIN account_coa c ON b.account_number = c.account_number 
                    WHERE a.name like '%$post%' and a.module like '%$module%' ORDER BY a.name ASC");
            }else{
                $send = $this->crud->reads('journal_types', ["name" => $post, "module" => $module], [], "", "name", "asc");
            }
            
            echo json_encode($send);
        }
    }

    //GET DATATABLES
    public function datatables()
    {
        if ($this->input->post()) {
            $filters = json_decode($this->input->post('filterRules'));
            $page = $this->input->post('page');
            $rows = $this->input->post('rows');
            //Pagination 1-10
            $page   = isset($page) ? intval($page) : 1;
            $rows   = isset($rows) ? intval($rows) : 10;
            $offset = ($page - 1) * $rows;
            $result = array();
            //Select Query
            $this->db->select('a.*, b.account_name');
            $this->db->from('journal_types a');
            $this->db->join('account_coa b', 'a.account_number = b.account_number', 'left');
            if (@count($filters) > 0) {
                foreach ($filters as $filter) {
                    $this->db->like($filter->field, $filter->value);
                }
            }
            //Total Data
            $totalRows = $this->db->count_all_results('', false);
            //Limit 1 - 10
            $this->db->limit($rows, $offset);
            //Get Data Array
            $records = $this->db->get()->result_array();
            //Mapping Data
            $result['total'] = $totalRows;
            $result = array_merge($result, ['rows' => $records]);
            echo json_encode($result);
        }
    }
    //CREATE DATA
    public function create()
    {
        if ($this->input->post()) {
            if ($this->form_validation->run() == TRUE) {
                $post = $this->input->post();
                $send = $this->crud->create('journal_types', $post);
                echo $send;
            } else {
                show_error(validation_errors());
            }
        } else {
            show_error("Cannot Process your request");
        }
    }
    //UPDATE DATA
    public function update()
    {
        if ($this->input->post()) {
            if ($this->form_validation->run() == TRUE) {
                $id   = base64_decode($this->input->get('id'));
                $post = $this->input->post();
                $send = $this->crud->update('journal_types', ["id" => $id], $post);
                echo $send;
            } else {
                show_error(validation_errors());
            }
        } else {
            show_error("Cannot Process your request");
        }
    }
    //DELETE DATA
    public function delete()
    {
        $data = $this->input->post();
        $send = $this->crud->delete('journal_types', $data);
        echo $send;
    }

    //PRINT & EXCEL DATA
    public function print($option = "")
    {
        if ($option == "excel") {
            $format  = date("Ymd");
            header("Content-type: application/vnd-ms-excel");
            header("Content-Disposition: attachment; filename=journal_types_$format.xls");
        }
        //Config
        $this->db->select('*');
        $this->db->from('config');
        $config = $this->db->get()->row();

        $this->db->select('a.*, b.account_name');
        $this->db->from('journal_types a');
        $this->db->join('account_coa b', 'a.account_number = b.account_number', 'left');
        $records = $this->db->get()->result_array();

        $html = '<html><head><title>Print Data</title></head><style>body {font-family: Arial, Helvetica, sans-serif;}#customers {border-collapse: collapse;width: 100%;font-size: 12px;}#customers td, #customers th {border: 1px solid #ddd;padding: 2px;}#customers tr:nth-child(even){background-color: #f2f2f2;}#customers tr:hover {background-color: #ddd;}#customers th {padding-top: 2px;padding-bottom: 2px;text-align: left;color: black;}</style><body>
        <center>
            <div style="float: left; font-size: 12px; text-align: left;">
                <table style="width: 100%;">
                    <tr>
                        <td width="50" style="font-size: 12px; vertical-align: top; text-align: center; vertical-align:jus margin-right:10px;">
                            <img src="' . $config->favicon . '" width="30">
                        </td>
                        <td style="font-size: 14px; text-align: left; margin:2px;">
                            <b>' . $config->name . '</b><br>
                            <small>MASTER JOURNAL TYPES</small>
                        </td>
                    </tr>
                </table>
            </div>
            <div style="float: right; font-size: 12px; text-align: right;">
                Print Date ' . date("d M Y H:m:s") . ' <br>
                Print By ' . $this->session->username . '  
            </div>
        </center>
        <br><br><br>
        
        <table id="customers" border="1">
            <tr>
                <th width="20">No</th>
                <th>Journal Code</th>
                <th>Journal Name</th>
                <th>Type</th>
                <th>Module</th>
                <th>Account No</th>
                <th>Account Name</th>
                <th>Status</th>
            </tr>';
        $no = 1;
        foreach ($records as $data) {
            $html .= '<tr>
                    <td>' . $no . '</td>
                    <td>' . $data['number'] . '</td>
                    <td>' . $data['name'] . '</td>
                    <td>' . $data['type'] . '</td>
                    <td>' . $data['module'] . '</td>
                    <td>' . $data['account_number'] . '</td>
                    <td>' . $data['account_name'] . '</td>
                    <td>' . $data['status'] . '</td>';
            $no++;
        }
        $html .= '</table></body></html>';
        echo $html;
    }
}
